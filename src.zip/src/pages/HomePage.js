// src/pages/HomePage.js
import React from 'react';
import Header from '../components/Header';  // Import Header here if you want to display it on this page
import HotelCarousel from '../components/Carousel';
import Footer from '../components/Footer';  // Import Footer here if you want to display it on this page

const HomePage = () => {
  return (
    <div>
      {/* Header and Footer are already included once here */}
      <Header />
      <HotelCarousel />
      <div className="container mt-4">
        
      </div>
     
    </div>
  );
};

export default HomePage;
