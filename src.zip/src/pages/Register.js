import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import './Register.css';

const Register = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!username || !password) {
      setError('All fields are required!');
      return;
    }

    try {
      // Basic Authentication credentials
      const auth = {
        username: 'admin', // Admin credentials for Basic Authentication
        password: 'admin123',
      };

      // Send the registration request with Basic Auth header
      const response = await axios.post('http://localhost:8080/users', 
        { username, password }, 
        {
          auth: auth,  // Add Basic Authentication
          headers: {
            'Content-Type': 'application/json', // Ensure correct content type
          },
        }
      );

      // If registration is successful, redirect to login page
      navigate('/login');
    } catch (err) {
      setError('Error registering user. Please try again.');
      console.error(err.response?.data || err); // Log more detailed error info from backend if available
    }
  };

  return (
    <div className="register-container">
      <h2>Register</h2>
      <form onSubmit={handleSubmit} className="register-form">
        {error && <p className="error">{error}</p>}

        <div className="form-group">
          <label>Username</label>
          <input
            type="text"
            placeholder="Enter username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
        </div>

        <div className="form-group">
          <label>Password</label>
          <input
            type="password"
            placeholder="Enter password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>

        <button type="submit" className="btn-submit">Submit</button>
      </form>

      <div className="redirect-link">
        <p>Already registered? <a href="/login">Login</a></p>
      </div>
    </div>
  );
};

export default Register;
