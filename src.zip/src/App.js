import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import NavbarComponent from './components/Navbar'; // Navbar component
import HomePage from './pages/HomePage'; // HomePage component
import Login from './pages/Login'; // Login page
import Register from './pages/Register'; // Register page
import Footer from './components/Footer'; // Footer component

function App() {
  return (
    <Router>
      <NavbarComponent />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/rooms" element={<div>Rooms Page</div>} />
      </Routes>
      <Footer />
    </Router>
  );
}

export default App;
