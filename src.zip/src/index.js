// src/index.js
import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';  // Only render the App component
import 'bootstrap/dist/css/bootstrap.min.css';  // Import Bootstrap

ReactDOM.render(
  <App />,
  document.getElementById('root')
);

