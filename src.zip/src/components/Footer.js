// src/components/Footer.js
import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';

const Footer = () => {
  return (
    <footer className="bg-dark text-white text-center p-4">
      <Container>
        <Row>
          <Col>&copy; 2024 Hotel Management System</Col>
        </Row>
        <Row>
          <Col>Email: contact@hotel.com</Col>
        </Row>
      </Container>
    </footer>
  );
};

export default Footer;
