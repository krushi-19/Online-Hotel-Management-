// src/components/HotelCarousel.js

import React from 'react';
import { Carousel } from 'react-bootstrap';
import download from '../images/download.jpeg';  // Import image from src/images
import room from '../images/room.jpeg';  // Import image from src/images

const HotelCarousel = () => {
  return (
    <Carousel>
      <Carousel.Item>
        <img
          className="d-block w-100 carousel-img"
          src={download}  // Using imported image
          alt="First slide"
        />
        <Carousel.Caption>
          <h3>Luxury Room</h3>
          <p>Enjoy your stay in our luxury suite.</p>
        </Carousel.Caption>
      </Carousel.Item>

      <Carousel.Item>
        <img
          className="d-block w-100 carousel-img"
          src={room}  // Using imported image
          alt="Second slide"
        />
        <Carousel.Caption>
          <h3>Ocean View</h3>
          <p>Experience a breathtaking ocean view.</p>
        </Carousel.Caption>
      </Carousel.Item>
    </Carousel>
  );
};

export default HotelCarousel;
