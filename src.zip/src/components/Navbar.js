import React from 'react';
import { Navbar, Nav, Container } from 'react-bootstrap';
import { Link, useLocation } from 'react-router-dom'; // Link instead of <a> tag

const NavbarComponent = () => {
  const location = useLocation(); // Get the current location (path) from the URL

  return (
    <Navbar bg="light" expand="lg">
      <Container>
        {/* Home link should be always visible except when on Home page */}
        <Navbar.Brand as={Link} to="/">Hotel Management</Navbar.Brand>

        <Nav className="ml-auto">
          {/* Conditionally render Home link if not on Home page */}
          {location.pathname !== '/' && (
            <Nav.Link as={Link} to="/">Home</Nav.Link>
          )}

          {/* Conditionally render Login and Register links based on the current page */}
          {location.pathname !== '/login' && (
            <Nav.Link as={Link} to="/login">Login</Nav.Link>
          )}
          {location.pathname !== '/register' && (
            <Nav.Link as={Link} to="/register">Register</Nav.Link>
          )}

          {/* Always show Rooms link */}
          <Nav.Link as={Link} to="/rooms">Rooms</Nav.Link>
        </Nav>
      </Container>
    </Navbar>
  );
};

export default NavbarComponent;
