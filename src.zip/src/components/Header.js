// src/components/Header.js
import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';

const Header = () => {
  return (
    <header className="bg-dark text-white text-center py-5">
      <Container>
        <Row>
          <Col>
            <h1>Welcome to Our Hotel Management System</h1>
            <p>Your comfort is our priority!</p>
          </Col>
        </Row>
      </Container>
    </header>
  );
};

export default Header;
