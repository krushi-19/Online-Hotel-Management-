package com.hotel.user_service.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfiguration;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

import com.hotel.user_service.entity.User;
import com.hotel.user_service.repository.UserRepository;

@Configuration
@EnableMethodSecurity // For enabling `@PreAuthorize`
public class SecurityConfig {
	
//	@Autowired
//	public UserRepository userRepository;
//
//
//	@Bean
//	CommandLineRunner initDatabase(UserRepository userRepository) {
//	    return args -> {
//	        if (userRepository.findByUsername("admin").isEmpty()) {
//	            User admin = new User();
//	            admin.setUsername("admin");
//            admin.setPassword(new BCryptPasswordEncoder().encode("admin123"));
//	            admin.setRole("ADMIN");
//	            userRepository.save(admin);	        }
//
//	        if (userRepository.findByUsername("user").isEmpty()) {
//	            User user = new User();
//	            user.setUsername("user");
//	            user.setPassword(new BCryptPasswordEncoder().encode("user123"));
//	            user.setRole("USER");
//	            userRepository.save(user);
//	        }
//	    };
//	}


	@Bean
	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
	    http.csrf().disable()
	        .authorizeRequests()
	        .requestMatchers("/users/**").hasRole("ADMIN")
	        .anyRequest().authenticated()
	        .and()
	        .httpBasic(); // This enables basic authentication
	    return http.build();
	}

    
    @Bean
    public UserDetailsService userDetailsService(UserRepository userRepository) {
        return username -> userRepository.findByUsername(username)
                .map(user -> org.springframework.security.core.userdetails.User.builder()
                        .username(user.getUsername())
                        .password(user.getPassword())
                        .roles(user.getRole()) // Use "ADMIN" or "USER"
                        .build())
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}


